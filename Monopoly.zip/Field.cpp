#include "Field.h"

Field::Field()
{
}

Field::Field(int index)
{
}

int Field::getIndex() const
{
	return index;
}
